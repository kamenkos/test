package gume;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Assume;
import org.junit.Before;
import org.junit.Rule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.rules.ErrorCollector;
import org.junit.rules.TestName;
import org.junit.rules.TestRule;
import org.junit.rules.Timeout;
import org.junit.rules.ExpectedException;

class AutoGumeTest {
	public static AutoGuma ag;
	public static AutoGuma ag2;
	public static AutoGuma ag3;
	@Rule
	private final ErrorCollector ec = new ErrorCollector();
	@Rule 
	private final TestName name = new TestName();
	@Rule
	private final TestRule limit = Timeout.seconds(5);
	@Rule 
	public ExpectedException exception = ExpectedException.none();
	
	@Test
	public void testOS() {
		Assume.assumeTrue(System.getProperty("os.name").contains("Windows"));
	}
	
	@BeforeEach
	public void init() {
		ag = new AutoGuma("Wintera",true,14,200,100);
	}
	@Test
	public void testGetZimska() {
		try {
			assertEquals("getZimska",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			Boolean ocekRez = true;
			assertEquals(ocekRez,ag.getZimska());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testSetZimska() {
		
		try {
			assertEquals("getMarkaModel",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			ag.setZimska(false);
			Boolean ocekRez = false;
			assertEquals(ocekRez,ag.getZimska());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testGetMarkaModel() {
		try {
			assertEquals("getMarkaModel",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			String ocekRez = "Wintera";
			assertEquals(ocekRez,ag.getMarkaModel());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	
	@Test
	public void testSetMarkaModel() {
		
		try {
			assertEquals("getMarkaModel",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			exception.expect(RuntimeException.class);
			exception.expectMessage("Nije uneta marka gume");
			String ocekivaniRezultat = "Wintera";
			String stvarniRezultat = ag.getMarkaModel();
			ag.setMarkaModel(null);
			assertEquals(ocekivaniRezultat, stvarniRezultat);
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		
		

	}
	@Test
	public void testSetMarkaModel2() {
		
		try {
			assertEquals("getMarkaModel",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			String ocekivaniRezultat = "Wintera";
			String stvarniRezultat = ag.getMarkaModel();
			ag.setMarkaModel("Wintera");
			assertEquals(ocekivaniRezultat, stvarniRezultat);
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		
		

	}
	@Test
	public void testGetPrecnik() {
		try {
			assertEquals("getPrecnik",name.getMethodName());
		}
		catch(Throwable t)
		{
			ec.addError(t);
		}
		try {
			int ocekRez = 14;
			assertEquals(ocekRez,ag.getPrecnik());
		}
		catch(Throwable t)
		{
			ec.addError(t);
		}
	}
	@Test
	public void testSetPrecnik1() {
		try {
			assertEquals("setPrecnik",name.getMethodName());
		}
		catch(Throwable t)
		{
			ec.addError(t);
		}
		try {
		exception.expect(RuntimeException.class);
		exception.expectMessage("Precnik van opsega");
		int ocekRez = 10;
		ag.setPrecnik(10);
		assertEquals(ocekRez,ag.getPrecnik());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testSetPrecnik2() {
		try {
			assertEquals("setPrecnik",name.getMethodName());
		}
		catch(Throwable t)
		{
			ec.addError(t);
		}
		try {
		int ocekRez = 15;
		ag.setPrecnik(15);
		assertEquals(ocekRez,ag.getPrecnik());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testGetSirina() {
		try {
			assertEquals("getSirina",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			int ocekRez = 200;
			assertEquals(ocekRez,ag.getSirina());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	
	@Test
	public void testSetSirina1() {
		try {
			assertEquals("setSirina",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			exception.expect(RuntimeException.class);
			exception.expectMessage("Sirina van opsega");
			ag.setSirina(130);
			int ocekRez = 130;
			assertEquals(ocekRez,ag.getSirina());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testSetSirina2() {
		try {
			assertEquals("setSirina",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {			
			ag.setSirina(135);
			int ocekRez = 135;
			assertEquals(ocekRez,ag.getSirina());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testGetVisina() {
		try {
			assertEquals("getVisina",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {			
			int ocekRez = 100;
			assertEquals(ocekRez,ag.getVisina());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testSetVisina() {
		try {
			assertEquals("setVisina",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {			
			ag.setVisina(24);
			int ocekRez = 24;
			assertEquals(ocekRez,ag.getVisina());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testSetVisina2() {
		try {
			assertEquals("setVisina",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {			
			ag.setVisina(25);
			int ocekRez = 25;
			assertEquals(ocekRez,ag.getVisina());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testIzracunajCenu() {
		try {
			assertEquals("izracunajCenu",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {			
			double ocekRez = (ag.getPrecnik()*3+ag.getSirina()+ag.getVisina())*28.53;
			assertEquals(ocekRez,ag.izracunajCenu());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testPovoljnaGuma1() {
		try {
			assertEquals("povoljnaGuma",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			assertFalse(ag.povoljnaGuma());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testPovoljnaGuma2() {
		try {
			assertEquals("povoljnaGuma",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			ag.setSirina(50);
			ag.setVisina(50);
			ag.setPrecnik(10);
			assertTrue(ag.povoljnaGuma());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testToString() {
		try {
			assertEquals("toString",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			String ocekRez ="AutoGuma [markaModel=" + ag.getMarkaModel() + ", precnik=" + ag.getPrecnik() + ", sirina=" + ag.getSirina() + ", visina="+ ag.getVisina() + "]";
			assertEquals(ocekRez,ag.toString());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testEquals() {
		try {
			assertEquals("equals",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			ag2 = new AutoGuma("Wintera",true,14,200,100);
			assertTrue(ag.equals(ag2));
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testEquals2() {
		try {
			assertEquals("equals",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			ag2 = new AutoGuma("Michellin",true,14,200,100);
			assertFalse(ag.equals(ag2));
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testEquals3() {
		try {
			assertEquals("equals",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			ag2 = new AutoGuma("Wintera",true,15,200,100);
			assertTrue(ag.equals(ag2));
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testEquals4() {
		try {
			assertEquals("equals",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			ag2 = new AutoGuma("Wintera",true,14,201,100);
			assertTrue(ag.equals(ag2));
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testEquals5() {
		try {
			assertEquals("equals",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			ag2 = new AutoGuma("Wintera",true,14,200,101);
			assertTrue(ag.equals(ag2));
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testEquals6() {
		try {
			assertEquals("equals",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			ag3 = new AutoGuma(null,true,14,200,101);
			ag2 = new AutoGuma("Wintera",true,14,200,101);
			assertEquals(false,ag3.equals(ag2));
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testEquals7() {
		try {
			assertEquals("equals",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			
			assertTrue(ag.equals(ag));
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void testEquals8() {
		try {
			assertEquals("equals",name.getMethodName());
		}
		catch(Throwable t) {
			ec.addError(t);
		}
		try {
			VulkanizerskaRadnja VK = new VulkanizerskaRadnja();
			assertEquals(false, ag.equals(VK));
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@After
	public void destroy() {
		ag = null;
	}
	
	
}
