package gume;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Rule;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.rules.ErrorCollector;
import org.junit.rules.ExpectedException;
import org.junit.rules.TestName;
import org.junit.rules.TestRule;
import org.junit.rules.Timeout;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import java.util.Objects;

import gume.AutoGuma;
import gume.VulkanizerskaRadnja;

@RunWith(Parameterized.class)
class VulkanizerskaRadnjaTest {
	public VulkanizerskaRadnja VK;
	public AutoGuma a;
	
	public VulkanizerskaRadnjaTest(AutoGuma a){
		this.a = a;
	}
	
	@Rule
	private final TestRule limit = Timeout.seconds(5);
	@Rule
	private final TestName name = new TestName();
	@Rule 
	private final ExpectedException exception = ExpectedException.none();
	@Rule 
	private final ErrorCollector ec = new ErrorCollector();
	@Before
	public void init() {
		VK = new VulkanizerskaRadnja();
	}
	
	
	@Parameters
	public static Collection<Object[]> gume() {
		return Arrays.asList(new Object[][] {
			{new AutoGuma("Michelin", true, 18, 180, 40)},
			{new AutoGuma("Michelin", true, 18, 180, 40)},
			{new AutoGuma("Michelin", true, 18, 180, 40)},
			{new AutoGuma("Pireli", false, 19,170, 30)}
		});
	}
	@Test
	public void test1(){
		try {
			a = null;
			exception.expect(NullPointerException.class);
			exception.expectMessage("Guma ne sme biti null");
			VK.dodajGumu(a);
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void test2(){
		try {
			exception.expect(RuntimeException.class);
			exception.expectMessage("Guma vec postoji");
			VK.dodajGumu(a);
			VK.dodajGumu(a);
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	@Test
	public void test3(){
		try {
			assertFalse(VK.gume.contains(a));
			VK.dodajGumu(a);
			assertTrue(VK.gume.contains(a));
			
		}
		catch(Throwable t) {
			ec.addError(t);
		}
	}
	
}
