package gume;

import static org.junit.jupiter.api.Assertions.*;

import java.util.logging.Logger;

import org.junit.jupiter.api.Test;
import org.junit.platform.launcher.listeners.TestExecutionSummary.Failure;
import org.junit.platform.suite.api.Suite;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;


public class TestRunner {

	public static void main(String[] args) {
		Logger l = Logger.getLogger(TestRunner.class.toString());
		Result result = JUnitCore.runClasses(AutoGumeTests.class,VulkanizerskaRadnjaTestovi.class);
		
		for (org.junit.runner.notification.Failure f : result.getFailures()) {
			l.warning(f.toString());
		}
		
		l.info("Greske"+result.getRunTime());
		l.info("Broj izvrsenih testova:"+result.getRunCount());
		l.info("Uspesnih testova:"+(result.getRunCount()-result.getIgnoreCount()-result.getFailureCount()-result.getAssumptionFailureCount()));
		l.info("Preskoceno"+result.getIgnoreCount());
		l.info("Neuspesno"+result.getFailureCount());
		l.info("Dinamicki preskoceno"+result.getAssumptionFailureCount());
		
		if(result.wasSuccessful()) {
			l.info("Uspesno su izvrseni svi testovi");
		}
		else {
			l.warning("Nisu uspesno izvrseni svi testovi");
		}
	}

}
